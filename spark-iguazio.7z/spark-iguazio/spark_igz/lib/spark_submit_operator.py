import mlrun

def main(**kwargs):

    mlrun.set_environment(project="default")

    for k, v in kwargs.items():
        print(k, v)

    print("Here are the params: ", kwargs["params"])

    print(kwargs["params"]["module"])

    mlrun.run_function("igz_spark_submit", params=kwargs["params"])