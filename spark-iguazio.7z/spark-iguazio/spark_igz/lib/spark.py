from pyspark.sql import SparkSession
from mlrun import get_or_create_ctx
import sys

if __name__ == '__main__':
    print("This runs before the spark context!")
    context = get_or_create_ctx("spark-func")

    spark = SparkSession.builder.appName("Spark job").getOrCreate()

    print("This is function params", context.get_param("module"))
    print("This is a command line arg:", sys.argv)

    spark.stop()