import mlrun
import os

project = mlrun.set_environment(project="default")
sj = mlrun.new_function(kind = "spark",
                        command="/User/spark.py",
                        name="igz_spark_submit",
                        image=".igz_spark_submit")

# set spark driver config (gpu_type & gpus=<number_of_gpus>  supported too)
sj.with_driver_limits(cpu="1300m")
sj.with_driver_requests(cpu=1, mem="512m")

some_var = "1300m"
#sj.with_driver_requests(cpu={{some_var}})

# set spark executor config (gpu_type & gpus=<number_of_gpus> are supported too)
sj.with_executor_limits(cpu="1400m")
sj.with_executor_requests(cpu=1, mem="512m")

# adds fuse, daemon & iguazio's jars support
sj.with_igz_spark()

# args are also supported
sj.spec.args = ['test_arg']
sj.spec.deps['pyFiles'] = ['local:///User/mymods.egg'] #supports .py, .zip, .egg   --py-files

# add python module
#sj.spec.build.commands = ['pip install matplotlib']

# Number of executors
sj.spec.replicas = 1

#%%

sj.deploy()

