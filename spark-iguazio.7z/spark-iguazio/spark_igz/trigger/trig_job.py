import os
os.environ['MLRUN_DBPATH'] = 'https://mlrun-api.default-tenant.app.cvs-rx.iguazio-c0.com'
os.environ['MLRUN_ARTIFACT_PATH'] = '/User/artifacts/{{run.project}}'
os.environ['V3IO_USERNAME'] = 'abishek'
os.environ['V3IO_API'] = 'https://webapi.default-tenant.app.cvs-rx.iguazio-c0.com:8444/'
os.environ['V3IO_ACCESS_KEY'] = ''
import mlrun

def main(**kwargs):

    mlrun.set_environment(project="sparksimulation")

    sj = mlrun.new_function(kind = "spark",
                              project = "sparksimulation",
                              name="sparkjob",
                              command="v3io:///User/v3io/projects/sparksimulation/jobA.py",
                              image=".spark_igz_test")

    sj.with_driver_limits(cpu="1300m")
    sj.with_driver_requests(cpu=1, mem="512m")

    # set spark executor config (gpu_type & gpus=<number_of_gpus> are supported too)
    sj.with_executor_limits(cpu="1400m")
    sj.with_executor_requests(cpu=1, mem="512m")

    # adds fuse, daemon & iguazio's jars support
    sj.with_igz_spark()

    # args are also supported
    sj.spec.args = ['test_arg']
    sj.spec.deps['pyFiles'] = ['v3io:///User/v3io/projects/sparksimulation/jobA.py']  # supports .py, .zip, .egg   --py-files

    # add python module
    # sj.spec.build.commands = ['pip install matplotlib']

    # Number of executors
    sj.spec.replicas = 1

    sj.run()


if __name__ == '__main__': main()