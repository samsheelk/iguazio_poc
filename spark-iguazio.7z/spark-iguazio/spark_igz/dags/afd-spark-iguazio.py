from datetime import datetime
from airflow import DAG
from airflow.operators.python_operator import PythonOperator
import sys
sys.path.insert(0, 'v3io://projects/sparksimulation/spark_igz-1.0-py3.8.egg')
from spark_igz.trigger import trig_job
default_args = {"start_date": datetime(2020, 1, 1)}

with DAG(
    "afd-spark-iguazio",
    description="DAG to run a spark job on Iguazio",
    catchup=False,
    schedule_interval=None,
    default_args=default_args
) as dag:

    task_jobA = PythonOperator(
        task_id="jobA",
        python_callable=trig_job.main,
        params={"paramA": "jobA", "paramB": "spark_igz/modules/jobA.py"},
        provide_context=True
    )

    task_jobB = PythonOperator(
        task_id="jobB",
        python_callable=trig_job.main,
        params={"paramA": "jobB", "paramB": "spark_igz/modules/jobB.py"},
        provide_context=True
    )

    task_jobC = PythonOperator(
        task_id="jobC",
        python_callable=trig_job.main,
        params={"paramA": "jobC", "paramB": "spark_igz/modules/jobC.py"},
        provide_context=True
    )

    task_jobA >> task_jobB >> task_jobC