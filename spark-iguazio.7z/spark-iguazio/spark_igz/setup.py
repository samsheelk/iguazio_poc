from setuptools import setup, find_packages
from distutils.command.install_data import install_data

setup(name="spark_igz",
      version="1.0",
      packages=find_packages(),
      install_requires=[
          'pyspark'
          'mlrun'],
      cmdclass={'install_data' : install_data},
      data_files=[('configs', ['configs/nba.yml'])])
