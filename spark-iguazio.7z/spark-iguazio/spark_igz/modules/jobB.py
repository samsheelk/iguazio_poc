from spark_igz.modules.jobA import main as jobA
from pyspark.sql import functions as F

def main():
    df = jobA()
    df = df.filter(F.col('salary')>=4000)\
        .select(F.col('firstname'))
    df.show(False)